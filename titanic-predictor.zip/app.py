import streamlit as st
import pandas as pd

st.title("🚢 Titanic Overlevingsvoorspeller")
st.write("Deze app gebruikt een Excel-model om te voorspellen wie overleeft.")

age = st.number_input("Leeftijd", min_value=0, max_value=100, value=30)
sex = st.selectbox("Geslacht", ["male", "female"])

@st.cache_data
def laad_model():
    return pd.read_excel("data/teststst.xlsx")

model_df = laad_model()

def voorspel(age, sex, regels):
    for _, regel in regels.iterrows():
        if regel['min_age'] <= age <= regel['max_age']:
            if regel['sex'].lower() == 'any' or regel['sex'].lower() == sex.lower():
                return regel['prediction']
    return "Geen voorspelling beschikbaar"

if st.button("Voorspel"):
    resultaat = voorspel(age, sex, model_df)
    st.success(f"📊 Voorspelling: {resultaat}")
